import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {
  email: string = '';
  senha: string = '';
  mensagem: string = '';

  entrar(): void {
    const cadastroSalvo = localStorage.getItem('cadastro');

    if (cadastroSalvo) {
      const cliente = JSON.parse(cadastroSalvo);
      if (cliente.email === this.email && cliente.senha === this.senha) {
        this.mensagem = 'Login realizado com sucesso!';
        return;
      }
    }

    this.mensagem = 'Email ou senha inválidos.';
  }
}
