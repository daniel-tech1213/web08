import { Produto } from './produto';

export class ItemCesta {
  produto: Produto = new Produto();
  quantidade: number = 1;
  valorUnitario: number = 0;
  subtotal: number = 0;
}
